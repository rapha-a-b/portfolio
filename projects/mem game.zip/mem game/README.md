# memory-game
tech used:html css js-moudles  js
about:
simple cards memory game
